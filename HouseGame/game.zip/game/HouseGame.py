def id_to_name(id):
    a = id.split(sep='_')
    b = ''
    if len(a) == 1:
        b = str(a[0])
    else:
        for i in range(len(a) - 1):
            b += a[i] + ' '
        b += a[len(a) - 1]
    return b.capitalize()


class Item:
    """The abstract class for items. Item types will inherit this class' main attributes.
    """

    def __init__(self, id, location, *args):
        self.id = id
        self.name = id_to_name(id)
        self.location = location

    def __str__(self):
        return "{}\nLocated in: {}\n".format(self.name, self.location)


class Stationary(Item):

    def __init__(self, id, location):
        self.name = id_to_name(id)
        super().__init__(id, location)

    def __str__(self):
        return "{}\nLocated in: {}\n".format(self.name, self.location)


class Movable(Item):
    '''Movable items gain pick up and drop methods to move them around'''

    def __init__(self, id, location):
        self.name = id_to_name(id)
        super().__init__(id, location)

    def __str__(self):
        return "{}\nLocated in: {}\n".format(self.name, self.location)

    def PickUp(self):
        if self.location.lower() == CurrentLocation.lower():
            self.location = 'inventory'
        else:
            print('There\'s no such item here!')

    def Drop(self):
        if self.location.lower() == 'inventory':
            self.location = CurrentLocation
        else:
            print('You are not carrying such an item')


class Usable(Item):
    '''Usable Items will get a method that will print a custom piece of text when used. '''

    def __init__(self, id, location, use, text):
        self.use = use
        self.reads = id_to_name(text)
        self.name = id_to_name(id)
        super().__init__(id, location)

    def __str__(self):
        return "{}\nLocated in: {}\nUse Command: \'{}\'".format(self.name, self.location, self.use)


class Door:
    '''The door class includes the rooms the doors connect as well as the door status and door commands. '''

    def __init__(self, dir1, dir2, room1, room2, status):
        self.dir1 = dir1
        self.dir2 = dir2
        self.room1 = room1
        self.room2 = room2
        self.status = status

    def __str__(self):
        return "An {} door connects the {}'s {} side with the {}'s {} side.".format(self.status, self.room1, self.dir1,
                                                                                    self.room2, self.dir2)

    def OpenDoor(self):
        if self.status == 'closed':
            self.status = 'open'
            print('You have opened the door.')
        elif self.status == 'open':
            print('The door is already open')
        else:
            print('You can\'t open this door.')

    def UnlockDoor(self):
        fl = False
        for i in range(len(items)):
            if (items[i].name.lower() == 'key') and (items[i].location.lower() == 'inventory'):
                fl = True
        if fl == False:
            print('You do not have a key.')
        if fl == True:
            if self.status == 'locked':
                self.status = 'closed'
                print('You have unlocked the door.')
            else:
                print('The door is already unlocked.')

    def LockDoor(self):
        fl = False
        for i in range(len(items)):
            if (items[i].name.lower() == 'key') and (items[i].location.lower() == 'inventory'):
                fl = True
        if fl == False:
            print('You do not have a key.')
        if fl == True:
            if self.status == 'locked':
                print('The door is already locked')
            else:
                self.status = 'locked'
                print('You lock the door')

    def CloseDoor(self):
        if self.status == 'open':
            self.status = 'closed'
            print('You have closed the door.')
        else:
            print('The door is already closed')


def PickUp(item):
    if item.location.lower() == CurrentLocation.lower():
        item.location = 'inventory'
        print('You picked the {} up.'.format(item.name))
    else:
        print('There\'s no such item here!')


def Drop(item):
    if item.location.lower() == 'inventory':
        item.location = CurrentLocation
        print('You left the {} on the floor.'.format(item.name))
    else:
        print('You are not carrying such an item')


def UseItem(item):
    print(item.reads)


def StartUp():
    global doors
    global items
    global rooms
    global StartLocation
    global CurrentLocation
    global UseCommands
    global ItemClassID
    doors = []
    items = []
    rooms = []
    ItemClassID = []

    buffer = open('houseconfig.txt').read().split(sep='\n')
    for a in buffer:
        if a.startswith('room'):
            rooms.append(a.split()[1])
        if a.startswith('door'):
            doors.append(
                Door(a.split()[1].split(sep='-')[0], a.split()[1].split(sep='-')[1], a.split()[3], a.split()[4],
                     a.split()[2]))
        if a.startswith('item'):
            if a.split()[3].lower() == 'stationary':
                items.append(Stationary(a.split()[1], a.split()[2]))
                ItemClassID.append(0)
            if a.split()[3].lower() == 'movable':
                items.append(Movable(a.split()[1], a.split()[2]))
                ItemClassID.append(1)
            if a.split()[3].lower() == 'usable':
                items.append(Usable(a.split()[1], a.split()[2], a.split()[4], a.split(maxsplit=5)[5]))
                ItemClassID.append(
                    2)  # issubclass wasn't working for me so I made a flag to check the type of class later on
        if a.startswith('start'):
            StartLocation = a.split()[1]
            CurrentLocation = StartLocation


def LookAround():
    print('You are now in the {}.\n'.format(CurrentLocation.capitalize()))
    flag = False
    for i in range(len(items)):
        if items[i].location.lower() == CurrentLocation.lower():
            flag = True
    if flag == True:
        print('You can see the following item(s) in the room:', end='\n')
        for i in range(len(items)):
            if items[i].location.lower() == CurrentLocation.lower():
                print(items[i])

    for i in range(len(doors)):
        if doors[i].room1.lower() == CurrentLocation.lower():
            print('There is a(n) {} door on the {} of the room that leads to the {}.'.format(doors[i].status,
                                                                                             doors[i].dir1,
                                                                                             doors[i].room2))
        if doors[i].room2.lower() == CurrentLocation.lower():
            print('There is a(n) {} door on the {} of the room that leads to the {}.'.format(doors[i].status,
                                                                                             doors[i].dir2,
                                                                                             doors[i].room1))


def ViewInventory():
    flag1 = False
    for i in range(len(items)):
        if items[i].location.lower() == 'inventory':
            flag1 = True
    if flag1 == False:
        print('You are carrying nothing')
    else:
        print('You are carrying the following item(s)')
        for i in range(len(items)):
            if items[i].location.lower() == 'inventory':
                print(items[i])


def Move(To):
    global CurrentLocation
    valid = False
    for i in range(len(doors)):
        if (CurrentLocation.lower() == doors[i].room1.lower()) and (To.lower() == doors[i].dir1.lower()) and (
                doors[i].status.lower() == 'open'):
            CurrentLocation = doors[i].room2
            valid = True
            print('You are now in the {}.'.format(CurrentLocation))
        if (CurrentLocation.lower() == doors[i].room2.lower()) and (To.lower() == doors[i].dir2.lower()) and (
                doors[i].status.lower() == 'open'):
            CurrentLocation = doors[i].room1
            valid = True
            print('You are now in the {}.'.format(CurrentLocation))
    if valid == False:
        print('Invalid Move. Either there is no door there or the door is closed')


def ShowCommands():
    print("""Commands:
      'move d': moves you to an adjacent room if the door leading there is open
      'open d': opens a closed door in the direction d
      'close d': closes an open door in the direction d
      'lock d': locks an unlocked door in the direction d
      'unlock d': unlocks a locked door in the direction d
      'pick up x': picks an item up
      'drop x': drops an item on the ground
      'look around': tells you about your surroundings
      'inventory': Gives you info on items you are carrying(including special uses)
      'commands':Brings up this reminder
      'quit': Quits the game!
      *Directions are: N,S,E,W""")


def PlayerInput():
    global CurrentLocation
    plinput = input('What would you like to do next?\n').lower()
    listofmoves = []
    listofdirections = ['n', 's', 'e', 'w']
    movableitems = []
    usableitems = []
    Usecommands = []
    for i in range(len(items)):
        if ItemClassID[i] > 0:
            movableitems.append(items[i].name.lower())
        if ItemClassID[i] == 2:
            usableitems.append(items[i].name.lower())
            Usecommands.append(items[i].use.lower() + ' ' + items[i].name.lower())
    for i in range(len(doors)):
        listofmoves.append(doors[i].room1.lower() + ' ' + doors[i].dir1.lower())
        listofmoves.append(doors[i].room2.lower() + ' ' + doors[i].dir2.lower())
    if plinput.lower().startswith('move'):
        if (CurrentLocation.lower() + ' ' + plinput.lower().split()[1]) in listofmoves:
            Move(plinput.lower().split()[1])
        else:
            print('That is not a valid move')
    if plinput.startswith('open'):
        if plinput.split()[1] in listofdirections:
            for i in range(len(doors)):
                if plinput.split()[1].lower() == doors[i].dir1.lower() and CurrentLocation.lower() == doors[
                    i].room1.lower():
                    doors[i].OpenDoor()
                if plinput.split()[1].lower() == doors[i].dir2.lower() and CurrentLocation.lower() == doors[
                    i].room2.lower():
                    doors[i].OpenDoor()
    if plinput.startswith('close'):
        if plinput.split()[1] in listofdirections:
            for i in range(len(doors)):
                if plinput.split()[1].lower() == doors[i].dir1.lower() and CurrentLocation.lower() == doors[
                    i].room1.lower():
                    doors[i].CloseDoor()
                if plinput.split()[1].lower() == doors[i].dir2.lower() and CurrentLocation.lower() == doors[
                    i].room2.lower():
                    doors[i].CloseDoor()
    if plinput.startswith('lock'):
        if plinput.split()[1] in listofdirections:
            for i in range(len(doors)):
                if plinput.split()[1].lower() == doors[i].dir1.lower() and CurrentLocation.lower() == doors[
                    i].room1.lower():
                    doors[i].LockDoor()
                if plinput.split()[1].lower() == doors[i].dir2.lower() and CurrentLocation.lower() == doors[
                    i].room2.lower():
                    doors[i].LockDoor()
    if plinput.startswith('unlock'):
        if plinput.split()[1] in listofdirections:
            for i in range(len(doors)):
                if plinput.split()[1].lower() == doors[i].dir1.lower() and CurrentLocation.lower() == doors[
                    i].room1.lower():
                    doors[i].UnlockDoor()
                if plinput.split()[1].lower() == doors[i].dir2.lower() and CurrentLocation.lower() == doors[
                    i].room2.lower():
                    doors[i].UnlockDoor()
    if plinput.lower() == 'look around':
        LookAround()
    if plinput.lower() == 'quit':
        quit()
    if plinput.lower() == 'commands':
        ShowCommands()
    if plinput.lower() == 'inventory':
        ViewInventory()
    if plinput.startswith('pick up') and (((' '.join(plinput.split()[2:])).lower()) in movableitems):
        for i in range(len(items)):
            if (' '.join(plinput.split()[2:])).lower() == items[i].name.lower():
                PickUp(items[i])
    if plinput.startswith('drop') and plinput.split()[2] in movableitems:
        for i in range(len(items)):
            if (' '.join(plinput.split()[1:])).lower() == items[i].name.lower():
                Drop(items[i])
    if (plinput.startswith('use') or (plinput.lower() in Usecommands)) and ' '.join(
            plinput.split()[1:]) in movableitems:
        try:
            for i in range(len(items)):
                if (' '.join(plinput.split()[1:])).lower() == items[i].name.lower():
                    UseItem(items[i])
        except:
            for i in range(len(Usecommands)):
                if plinput.lower() == Usecommands[i]:
                    index = i
                    UseItem(items[index].name)


StartUp()
ShowCommands()
LookAround()

active = True
while active == True:
    PlayerInput()
